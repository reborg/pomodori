$:.unshift NSBundle.mainBundle.resourcePath.fileSystemRepresentation
load 'lib/main.rb'
