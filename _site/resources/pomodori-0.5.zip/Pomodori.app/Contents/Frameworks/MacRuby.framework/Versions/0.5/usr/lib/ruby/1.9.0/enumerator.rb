# Enumerator is builtin in core, this file exists for backward compatibility.
