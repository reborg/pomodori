require 'rdoc'

module RDoc::RI

  class Error < RDoc::Error; end

end

