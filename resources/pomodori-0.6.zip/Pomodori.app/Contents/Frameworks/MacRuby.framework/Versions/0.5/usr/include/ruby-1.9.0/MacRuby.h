#define RUBY_INCLUDED_AS_FRAMEWORK 1
#include <Foundation/Foundation.h>
#include "ruby/ruby.h"
