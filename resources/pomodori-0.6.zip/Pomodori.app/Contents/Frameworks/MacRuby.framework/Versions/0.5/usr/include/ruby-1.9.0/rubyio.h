#include <ruby/io.h>
