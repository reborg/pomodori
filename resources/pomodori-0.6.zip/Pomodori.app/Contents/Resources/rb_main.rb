$:.map! { |x| x.sub(/^\/Library\/Frameworks/, NSBundle.mainBundle.privateFrameworksPath) }
$:.unshift NSBundle.mainBundle.resourcePath.fileSystemRepresentation
begin
  load 'lib/main.rb'
rescue Exception => e
  STDERR.puts e.message
  e.backtrace.each { |bt| STDERR.puts bt }
end
